package dto;

public class MemberDto {
	private String id;
	private String name;
	private String tel;
	private String dept;
	
	public MemberDto(String id, String name, String tel, String dept) {
		super();
		this.id = id;
		this.name = name;
		this.tel = tel;
		this.dept = dept;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "MemberDto [id=" + id + ", name=" + name + ", tel=" + tel + ", dept=" + dept + "]";
	}
	
	

}
